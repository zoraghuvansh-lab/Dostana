# Dostana Live Video Starter (Android)

This version adds a LiveKit Android SDK connection scaffold to the native Android app. It is **not a complete production service** and cannot make a call until you configure a LiveKit server and a secure token backend.

## Build
- Android Gradle project, Kotlin.
- Cloud build workflow in `.github/workflows/android.yml`.
- Minimum Android API 24; compile SDK 35.
- Camera/microphone permissions are declared.

## Enable real room connection
1. Create a LiveKit Cloud project at https://cloud.livekit.io/ or operate a compatible LiveKit server.
2. Deploy a backend endpoint that authenticates your app user and issues a short-lived room participant token. See https://docs.livekit.io/home/server/generating-tokens/.
3. Never embed LiveKit API secret in Android code, GitHub files, or client-side JavaScript.
4. Enter the `wss://` server URL and a short-lived room token in the call setup screen.
5. Connect two devices/users to the same room with separate participant tokens.

## Current limitations
- CallActivity can connect to a LiveKit room when configured, but remote/local video rendering UI is not implemented yet. Connection status alone does not mean the user sees the other participant.
- No login, matchmaking/signaling backend, wallet, real payment, server-side minute billing, host payouts, age verification, report/block workflow or admin authentication.
- The existing wallet/earnings screens are demo-only. Do not accept real money or pay hosts from them.
- Production needs server-authoritative billing, webhook reconciliation, fraud prevention, privacy policy, terms, moderation and security testing.
- This starter is intended for ordinary, non-explicit social video chat. Google Play policy does not allow apps centered on sexual gratification or compensated sexual services.

## Cloud build
Push all files to a GitHub repository, open Actions, run `Build Dostana Debug APK`, then download `Dostana-debug-apk` from workflow artifacts. Build may require version adjustments as upstream dependencies change.


## Updates in this package
- LiveKit Android dependency updated to 2.29.0 per current SDK docs.
- Call screen now initializes a video renderer and listens for a subscribed remote video track.
- Added `backend/` Node.js token service starter. It must be deployed and configured with LiveKit credentials before a real room can be joined.
- This remains an integration starter; no APK has been built in this environment and no real calls are possible until the backend is deployed and the call screen is configured to obtain tokens securely.
