plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.dostana.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.dostana.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // LiveKit Android SDK. Requires a LiveKit server/cloud project and a server-issued room token.
    implementation("io.livekit:livekit-android:2.29.0")
}
