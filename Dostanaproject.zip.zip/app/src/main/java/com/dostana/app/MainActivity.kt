package com.dostana.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private var hindi = false
    private var balance = 500
    private val purple = Color.rgb(124,58,237)
    private val bg = Color.rgb(247,245,255)
    private lateinit var body: LinearLayout
    private val names = listOf("Aarav", "Meera", "Kabir", "Anaya")
    private val emojis = listOf("😊", "🌼", "😎", "🌸")
    private val online = listOf(true, true, true, false)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun rounded(c:Int,r:Int=18)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
    private fun txt(s:String,size:Float,color:Int=Color.rgb(25,21,42),bold:Boolean=false)=TextView(this).apply{ text=s;textSize=size;setTextColor(color);if(bold)setTypeface(null,android.graphics.Typeface.BOLD) }
    private fun btn(s:String,action:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setTextColor(Color.WHITE);background=rounded(purple,12);setOnClickListener{action()}}
    private fun start(title:String,sub:String){
        val root=LinearLayout(this).apply{orientation=1;setBackgroundColor(bg)}
        val header=LinearLayout(this).apply{orientation=1;setPadding(dp(18),dp(22),dp(18),dp(20));background=rounded(purple,0)}
        val top=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL}
        top.addView(txt("💜 Dostana",25f,Color.WHITE,true),LinearLayout.LayoutParams(0,-2,1f))
        top.addView(btn(if(hindi)"English" else "हिंदी"){hindi=!hindi;home()})
        header.addView(top); val h=txt(title,22f,Color.WHITE,true);h.setPadding(0,dp(18),0,dp(4));header.addView(h);header.addView(txt(sub,14f,Color.WHITE))
        root.addView(header)
        val scroll=ScrollView(this);body=LinearLayout(this).apply{orientation=1;setPadding(dp(15),dp(15),dp(15),dp(20))}
        scroll.addView(body);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER}
        nav.addView(btn(if(hindi)"⌂ होम" else "⌂ Home"){home()},LinearLayout.LayoutParams(0,dp(50),1f))
        nav.addView(btn(if(hindi)"◉ कमाई" else "◉ Earnings"){earnings()},LinearLayout.LayoutParams(0,dp(50),1f))
        nav.addView(btn(if(hindi)"⚙ एडमिन" else "⚙ Admin"){admin()},LinearLayout.LayoutParams(0,dp(50),1f))
        root.addView(nav);setContentView(root)
    }
    private fun card(v:android.view.View){val c=LinearLayout(this).apply{orientation=1;setPadding(dp(13),dp(12),dp(13),dp(12));background=rounded(Color.WHITE)};c.addView(v);val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);body.addView(c,lp)}
    private fun home(){
        start(if(hindi)"अच्छी बातचीत की शुरुआत यहीं से।" else "Good conversations start here.",if(hindi)"सम्मान से बात करें, दोस्ती बढ़ाएँ।" else "Meet people, talk respectfully, make a connection.")
        body.addView(txt(if(hindi)"उपलब्ध होस्ट" else "Available hosts",18f,Color.DKGRAY,true))
        names.indices.forEach{i->
            val row=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL}
            val info=LinearLayout(this).apply{orientation=1}
            info.addView(txt("${emojis[i]}  ${names[i]}",18f,Color.DKGRAY,true))
            info.addView(txt(if(online[i])"● Online" else "○ Offline",12f,if(online[i])Color.rgb(22,132,91) else Color.GRAY))
            info.addView(txt("₹8 / min · demo rate",13f,Color.GRAY))
            row.addView(info,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(btn(if(hindi)"वीडियो कॉल" else "Video call"){if(!online[i])Toast.makeText(this,"Host offline",Toast.LENGTH_SHORT).show() else {
                val it=Intent(this,CallActivity::class.java);it.putExtra("host",names[i]);it.putExtra("emoji",emojis[i]);startActivity(it)
            }})
            card(row)
        }
        val wallet=LinearLayout(this).apply{orientation=1;setPadding(dp(15),dp(15),dp(15),dp(15));background=rounded(Color.rgb(33,23,53))}
        wallet.addView(txt(if(hindi)"डेमो वॉलेट बैलेंस" else "Demo wallet balance",14f,Color.LTGRAY))
        wallet.addView(txt("₹$balance",28f,Color.WHITE,true))
        wallet.addView(btn(if(hindi)"+ ₹100 डेमो जोड़ें" else "+ Add ₹100 demo money"){balance+=100;home();Toast.makeText(this,"Demo only — no real money",Toast.LENGTH_LONG).show()})
        body.addView(wallet);body.addView(txt(if(hindi)"लाइव कॉल के लिए LiveKit सर्वर URL और सर्वर द्वारा जारी token आवश्यक है।" else "Live calls require a LiveKit server URL and a server-issued room token.",12f,Color.GRAY))
    }
    private fun earnings(){start(if(hindi)"होस्ट की कमाई" else "Host earnings","Demo only");card(txt("₹0 · ${if(hindi)"डेमो कमाई" else "Demo earnings"}",20f,Color.DKGRAY,true));card(txt(if(hindi)"असली payout अभी सक्षम नहीं है।" else "Real host payouts are not enabled.",14f,Color.GRAY))}
    private fun admin(){start(if(hindi)"एडमिन सारांश" else "Admin overview","Demo only");card(txt(if(hindi)"यह स्थानीय प्रोटोटाइप है।" else "This is a local prototype.",16f));card(txt(if(hindi)"वास्तविक यूज़र, भुगतान या होस्ट कमाई प्रबंधित करने से पहले सुरक्षित बैकएंड जोड़ें।" else "Add a secure backend before managing real users, payments or host earnings.",13f,Color.GRAY))}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);home()}
}
