package com.dostana.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import io.livekit.android.LiveKit
import io.livekit.android.events.RoomEvent
import io.livekit.android.room.Room
import io.livekit.android.room.track.VideoTrack
import io.livekit.android.renderer.SurfaceViewRenderer
import kotlinx.coroutines.launch

/**
 * LiveKit call screen.
 *
 * Required before use:
 * - Configure a token backend (see backend/README.md in the ZIP).
 * - Set DOSTANA_TOKEN_ENDPOINT in local.properties / BuildConfig in a production implementation.
 * For this starter, URL + short-lived room token can be entered manually.
 * Never embed LiveKit API secrets in this app.
 */
class CallActivity : Activity() {
    private var room: Room? = null
    private lateinit var status: TextView
    private lateinit var urlInput: EditText
    private lateinit var tokenInput: EditText
    private lateinit var remoteVideo: SurfaceViewRenderer

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(14).toFloat() }
    private fun label(s: String, size: Float = 15f, color: Int = Color.DKGRAY) =
        TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(0, dp(5), 0, dp(5)) }
    private fun btn(s: String, fn: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(Color.rgb(124, 58, 237)); setOnClickListener { fn() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val host = intent.getStringExtra("host") ?: "Host"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            setBackgroundColor(Color.rgb(247, 245, 255))
        }
        root.addView(label("💜 Dostana · Live video", 23f, Color.rgb(91, 33, 182)))
        root.addView(label("Calling: $host", 18f))
        remoteVideo = SurfaceViewRenderer(this)
        remoteVideo.setBackgroundColor(Color.BLACK)
        root.addView(remoteVideo, LinearLayout.LayoutParams(-1, dp(250)))
        status = label("Not connected. Configure server URL and a short-lived token.", 13f, Color.DKGRAY)
        root.addView(status)
        root.addView(label("LiveKit server URL (wss://…)", 14f))
        urlInput = EditText(this).apply { hint = "wss://your-project.livekit.cloud"; singleLine = true }
        root.addView(urlInput, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(label("Room token (from your secure backend)", 14f))
        tokenInput = EditText(this).apply { hint = "Paste short-lived participant token"; minLines = 2 }
        root.addView(tokenInput, LinearLayout.LayoutParams(-1, dp(82)))
        root.addView(btn("Connect to live call") { requestPermissionsThenConnect() }, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(btn("End call / Disconnect") { disconnectRoom() }, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(label("A second participant must join the same room to see their video. This starter does not yet implement user login, matchmaking, paid billing or payouts.", 12f, Color.GRAY))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestPermissionsThenConnect() {
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
            .toTypedArray()
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed, 44)
            status.text = "Allow camera and microphone, then tap Connect again."
            return
        }
        connectRoom()
    }

    private fun connectRoom() {
        val server = urlInput.text.toString().trim()
        val token = tokenInput.text.toString().trim()
        if (!server.startsWith("wss://") || token.isBlank()) {
            status.text = "Enter a valid wss:// URL and server-issued token first."
            return
        }
        status.text = "Connecting…"
        lifecycleScope.launch {
            try {
                val newRoom = LiveKit.create(applicationContext)
                room = newRoom
                newRoom.initVideoRenderer(remoteVideo)
                launch {
                    newRoom.events.collect { event ->
                        when (event) {
                            is RoomEvent.TrackSubscribed -> {
                                val track = event.track
                                if (track is VideoTrack) {
                                    track.addRenderer(remoteVideo)
                                    status.text = "Connected. Remote video track received."
                                }
                            }
                            is RoomEvent.ParticipantConnected -> status.text = "Another participant joined."
                            else -> {}
                        }
                    }
                }
                newRoom.connect(server, token)
                newRoom.localParticipant.setMicrophoneEnabled(true)
                newRoom.localParticipant.setCameraEnabled(true)
                status.text = "Connected to room. Waiting for the other participant…"
            } catch (e: Exception) {
                status.text = "Connection failed: ${e.message ?: "check URL, token and internet"}"
            }
        }
    }

    private fun disconnectRoom() {
        try { room?.disconnect() } catch (_: Exception) {}
        room = null
        status.text = "Disconnected."
    }

    override fun onDestroy() {
        try { room?.disconnect() } catch (_: Exception) {}
        super.onDestroy()
    }
}
