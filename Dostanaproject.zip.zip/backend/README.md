# Dostana token service (starter)

This service signs short-lived LiveKit room tokens. It is a scaffold, not a production-ready auth service.

## Setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill values from your LiveKit project. Never commit `.env`.
4. Export those variables in your host environment and run `npm start`.
5. `POST /token` JSON: `{"roomName":"demo-room-1","identity":"user-1001"}` with header `x-dostana-key: <DOSTANA_TOKEN_API_KEY>`.

## Production requirements before public use
- Replace the shared setup key with real account authentication (Firebase/Auth0/custom auth), server-side authorization, abuse/rate limiting and audit logs.
- Verify users and room membership; never trust arbitrary client-supplied identity/room.
- Use HTTPS, secrets manager, logging/monitoring and rate limits.
- Add billing only on the server, based on trusted call/participant events; handle disconnects, refunds and fraud.
- This starter does not implement payments, host payouts, age verification, reporting/moderation or admin authentication.
