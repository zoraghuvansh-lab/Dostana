import express from "express";
import { AccessToken } from "livekit-server-sdk";

const app = express();
app.use(express.json());

const PORT = Number(process.env.PORT || 8080);
const LIVEKIT_URL = process.env.LIVEKIT_URL;
const LIVEKIT_API_KEY = process.env.LIVEKIT_API_KEY;
const LIVEKIT_API_SECRET = process.env.LIVEKIT_API_SECRET;
const TOKEN_API_KEY = process.env.DOSTANA_TOKEN_API_KEY;

app.get("/health", (_req, res) => res.json({ ok: true, service: "dostana-token-service" }));

app.post("/token", async (req, res) => {
  try {
    // Temporary server-to-server protection for setup. Production must use real user auth
    // and verify the caller's account, age eligibility, room permissions and rate limits.
    if (!TOKEN_API_KEY || req.header("x-dostana-key") !== TOKEN_API_KEY) {
      return res.status(401).json({ error: "unauthorized" });
    }
    if (!LIVEKIT_URL || !LIVEKIT_API_KEY || !LIVEKIT_API_SECRET) {
      return res.status(503).json({ error: "LiveKit server environment is not configured" });
    }
    const { roomName, identity } = req.body || {};
    if (typeof roomName !== "string" || !/^[a-zA-Z0-9_-]{3,80}$/.test(roomName)) {
      return res.status(400).json({ error: "invalid roomName" });
    }
    if (typeof identity !== "string" || !/^[a-zA-Z0-9_-]{3,80}$/.test(identity)) {
      return res.status(400).json({ error: "invalid identity" });
    }
    const token = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
      identity,
      ttl: "10m",
    });
    token.addGrant({ roomJoin: true, room: roomName, canPublish: true, canSubscribe: true });
    const jwt = await token.toJwt();
    res.json({ serverUrl: LIVEKIT_URL, token: jwt, roomName, identity, expiresIn: 600 });
  } catch (err) {
    console.error("token issue failed", err);
    res.status(500).json({ error: "token_issue_failed" });
  }
});

app.listen(PORT, () => console.log(`Dostana token service listening on ${PORT}`));
